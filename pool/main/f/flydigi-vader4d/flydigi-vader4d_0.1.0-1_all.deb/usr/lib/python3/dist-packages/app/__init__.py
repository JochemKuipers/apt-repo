"""Minimal app package for flydigi-ctl."""
