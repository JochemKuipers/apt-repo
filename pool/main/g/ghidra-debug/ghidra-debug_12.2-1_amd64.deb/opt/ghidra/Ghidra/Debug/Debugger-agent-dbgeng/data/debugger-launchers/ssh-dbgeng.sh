#!/usr/bin/env bash
## ###
# IP: GHIDRA
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
##
#@title dbgeng via ssh (shell)
#@image-opt env:OPT_TARGET_IMG
#@desc <html><body width="300px">
#@desc   <h3>Launch with <tt>dbgeng</tt> via <tt>ssh</tt></h3>
#@desc   <p>
#@desc     This will start <tt>dbgeng</tt> on the remote system via a Python interpreter.
#@desc     For setup instructions, press <b>F1</b>.
#@desc   </p>
#@desc </body></html>
#@menu-group dbgeng
#@icon icon.debugger
#@help dbgeng#ssh
#@depends Debugger-rmi-trace
#@env OPT_TARGET_IMG:str="" "Image" "The target binary executable image"
#@env OPT_TARGET_ARGS:str="" "Arguments" "Command-line arguments to pass to the target"
#@env OPT_SSH_PATH:file="ssh" "ssh command" "The path to ssh on the local system. Omit the full path to resolve using the system PATH."
#@env OPT_HOST:str="localhost" "[User@]Host" "The hostname or user@host"
#@env OPT_REMOTE_PORT:int=12345 "Remote Trace RMI Port" "A free port on the remote end to receive and forward the Trace RMI connection."
#@env OPT_EXTRA_SSH_ARGS:str="" "Extra ssh arguments" "Extra arguments to pass to ssh. Use with care."
#@env OPT_PYTHON_EXE:file!="python" "Python command" "The path to the Python 3 interpreter. Omit the full path to resolve using the system PATH."
#@env OPT_PYTHON_ARGS:str="" "python cmd args" "Arguments passed to python (versus the target)"
#@env OPT_USE_DBGMODEL:bool=true "Use dbgmodel" "Load and use dbgmodel.dll if it is available."
#@env WINDBG_DIR:dir="C:\\Windows\\System32" "Path to dbgeng.dll directory" "Path containing dbgeng and associated DLLS (if not Windows Kits)."

. ../support/dbgsetuputils.sh

target_image=$(echo $OPT_TARGET_IMG | sed 's/\\/\\\\/g')

OPT_OS_WINDOWS=true

function launch-dbg-scp() {
	local -a scpargs
	compute-scp-args "../support/local-dbgeng.py"

	"${scpargs[@]}"
}

function launch-dbg-ssh() {
	local -a sshargs
	compute-ssh-args true "$OPT_PYTHON_EXE -i $OPT_PYTHON_ARGS .\\local-dbgeng.py localhost:$OPT_REMOTE_PORT $OPT_USE_DBGMODEL $WINDBG_DIR $target_image $OPT_TARGET_ARGS"

	"${sshargs[@]}"
}

version=$(get-ghidra-version)

function do-installation() {
	local -a pipargs
	compute-dbg-pipinstall-args "'-f'" "os.environ['HOME']" "'ghidradbg>=$version'"
	local -a sshargs
	compute-ssh-args false "${pipargs[@]}"

	"${sshargs[@]}"
}

launch-dbg-scp
launch-dbg-ssh "$@"
if check-result-and-prompt-mitigation $? "
It appears ghidradbg is missing from the remote system. This can happen if you
forgot to install the required package. This can also happen if you installed
the packages to a different Python environment than is being used by the
remote's dbgeng.

This script is about to offer automatic resolution. If you'd like to resolve
this manually, answer no to the next question and then see Ghidra's help by
pressing F1 in the dialog of launch parameters.

WARNING: Answering yes to the next question will invoke pip to try to install
missing or incorrectly-versioned dependencies. It may attempt to find packages
from the PyPI mirror configured on the REMOTE system. If you have not configured
one, it will connect to the official one.

WARNING: We invoke pip with the --break-system-packages flag, because some
debuggers that embed Python (gdb, lldb) may not support virtual environments,
and so the packages must be installed to your user environment.

NOTE: This will copy Python wheels into the HOME directory of the user on the
remote system. You may be prompted to authenticate a few times while packages
are copied and installed.

NOTE: Automatic resolution will cause this session to terminate. When it has
finished, try launching again.
" "Would you like to install 'ghidradbg>=$version'?"; then

	echo "Copying Wheels to $OPT_HOST"
	if ! mitigate-scp-pymodules "Debugger-rmi-trace" "<SELF>"; then
		exit 1
	fi

	echo "Installing Wheels into Python"
	do-installation
fi
