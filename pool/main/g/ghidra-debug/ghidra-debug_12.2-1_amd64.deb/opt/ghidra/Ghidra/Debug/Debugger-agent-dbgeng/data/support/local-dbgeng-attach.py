## ###
# IP: GHIDRA
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
##

import os
import sys


cxn = os.getenv('GHIDRA_TRACE_RMI_ADDR')
target = os.getenv('OPT_TARGET_PID')
args = os.getenv('OPT_ATTACH_FLAGS')


def parse_parameters():
    global cxn, target, args
    os.environ['OPT_OS_WINDOWS'] = "true"
    argc = len(sys.argv)
    # This is the .bat case:
    if argc == 1:
        return True
    # Local and remote .ps1 cases
    if argc >= 5:
        cxn = sys.argv[1]
        os.environ['OPT_USE_DBGMODEL'] = sys.argv[2]
        os.environ['WINDBG_DIR'] = sys.argv[3]
        target = sys.argv[4]
        if argc > 5:
            args = sys.argv[5]
        return True
    print("Error: expected (cxn, use_dbgmodel, target, ...)")
    return False
    
def append_paths():
    sys.path.append(
        f"{os.getenv('MODULE_Debugger_rmi_trace_HOME')}/data/support")
    try:
        from gmodutils import ghidra_module_pypath
        sys.path.append(ghidra_module_pypath("Debugger-rmi-trace"))
        sys.path.append(ghidra_module_pypath())
    except Exception as e:
        pass


def main():
    global cxn, target, args
    append_paths()
    if not parse_parameters():
        return
        
    # Delay these imports until sys.path is patched
    try:
        import ghidradbg
    except ModuleNotFoundError:
        os._exit(253)
        
    from ghidradbg import commands as cmd
    from pybag.dbgeng import core as DbgEng
    from ghidradbg.hooks import on_state_changed
    from ghidradbg.util import dbg

    # So that the user can re-enter by typing repl()
    global repl
    repl = cmd.repl

    cmd.ghidra_trace_connect(cxn)
    cmd.ghidra_trace_attach(target, args, start_trace=False)

    # TODO: HACK
    try:
        dbg.wait()
    except KeyboardInterrupt as ki:
        dbg.interrupt()

    cmd.ghidra_trace_start(target)
    cmd.ghidra_trace_sync_enable()

    on_state_changed(DbgEng.DEBUG_CES_EXECUTION_STATUS,
                     DbgEng.DEBUG_STATUS_BREAK)
    cmd.repl()


if __name__ == '__main__':
    try:
        main()
    except SystemExit as x:
        if x.code != 0:
            print(f"Exited with code {x.code}")
