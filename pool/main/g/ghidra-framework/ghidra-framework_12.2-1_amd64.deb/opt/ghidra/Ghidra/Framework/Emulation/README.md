# Emulation
