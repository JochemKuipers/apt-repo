# tricore
